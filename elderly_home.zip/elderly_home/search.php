<?php
require_once 'config.php';
requireLogin();

$query = $_GET['q'] ?? '';
$results = ['residents' => [], 'staff' => []];

if (!empty($query)) {
    $search = "%$query%";
    // Search residents
    $stmt = $conn->prepare("SELECT id, first_name, last_name, room_number, status FROM residents WHERE first_name LIKE ? OR last_name LIKE ? OR room_number LIKE ?");
    $stmt->bind_param("sss", $search, $search, $search);
    $stmt->execute();
    $results['residents'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Search staff
    $stmt = $conn->prepare("SELECT id, first_name, last_name, role FROM staff WHERE first_name LIKE ? OR last_name LIKE ?");
    $stmt->bind_param("ss", $search, $search);
    $stmt->execute();
    $results['staff'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>
<?php include 'header.php'; ?>
<h1>Global Search</h1>

<form method="get" action="search.php">
    <div class="form-group search-box">
        <input type="text" name="q" placeholder="Enter name or room number..." value="<?php echo htmlspecialchars($query); ?>" required>
        <button type="submit" class="btn">Search</button>
    </div>
</form>

<?php if (!empty($query)): ?>
    <h2>Results for "<?php echo htmlspecialchars($query); ?>"</h2>

    <h3>Residents (<?php echo count($results['residents']); ?>)</h3>
    <?php if (count($results['residents']) > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Room</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($results['residents'] as $res): ?>
            <tr>
                <td><?php echo htmlspecialchars($res['first_name'] . ' ' . $res['last_name']); ?></td>
                <td><?php echo htmlspecialchars($res['room_number']); ?></td>
                <td><?php echo $res['status']; ?></td>
                <td><a href="residents.php?action=edit&id=<?php echo $res['id']; ?>">View</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No residents found.</p>
    <?php endif; ?>

    <h3>Staff (<?php echo count($results['staff']); ?>)</h3>
    <?php if (count($results['staff']) > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($results['staff'] as $st): ?>
            <tr>
                <td><?php echo htmlspecialchars($st['first_name'] . ' ' . $st['last_name']); ?></td>
                <td><?php echo $st['role']; ?></td>
                <td><a href="staff.php?action=edit&id=<?php echo $st['id']; ?>">View</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No staff found.</p>
    <?php endif; ?>
<?php endif; ?>
<?php include 'footer.php'; ?>