<?php
require_once 'config.php';
requireLogin();

$role = $_SESSION['user_role'];
$staff_id = $_SESSION['staff_id'] ?? 0;

// Counters for dashboard widgets
$resident_count = $conn->query("SELECT COUNT(*) as cnt FROM residents WHERE status='Active'")->fetch_assoc()['cnt'];
$appointment_today = $conn->query("SELECT COUNT(*) as cnt FROM appointments WHERE appointment_date = CURDATE()")->fetch_assoc()['cnt'];
$pending_bills = $conn->query("SELECT COUNT(*) as cnt FROM billing WHERE status='Pending'")->fetch_assoc()['cnt'];
$staff_count = $conn->query("SELECT COUNT(*) as cnt FROM staff")->fetch_assoc()['cnt'];
?>
<?php include 'header.php'; ?>
<h1>Dashboard</h1>
<p>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?> (<?php echo $role; ?>)</p>

<div class="dashboard-widgets">
    <div class="widget">
        <h3>Active Residents</h3>
        <p class="widget-number"><?php echo $resident_count; ?></p>
    </div>
    <div class="widget">
        <h3>Today's Appointments</h3>
        <p class="widget-number"><?php echo $appointment_today; ?></p>
    </div>
    <div class="widget">
        <h3>Pending Bills</h3>
        <p class="widget-number"><?php echo $pending_bills; ?></p>
    </div>
    <div class="widget">
        <h3>Staff Members</h3>
        <p class="widget-number"><?php echo $staff_count; ?></p>
    </div>
</div>

<!-- Quick links to main modules -->
<div class="quick-links">
    <h2>Quick Actions</h2>
    <ul>
        <?php if (in_array($role, ['Admin','Receptionist'])): ?>
            <li><a href="residents.php?action=add">Add New Resident</a></li>
        <?php endif; ?>
        <?php if ($role == 'Admin'): ?>
            <li><a href="staff.php?action=add">Add New Staff</a></li>
        <?php endif; ?>
        <?php if (in_array($role, ['Admin','Receptionist','Doctor'])): ?>
            <li><a href="appointments.php?action=schedule">Schedule Appointment</a></li>
        <?php endif; ?>
    </ul>
</div>

<!-- Upcoming appointments (if doctor, show theirs; if reception/admin, show all) -->
<h2>Upcoming Appointments</h2>
<?php
$sql = "SELECT a.*, r.first_name as r_first, r.last_name as r_last, s.first_name as s_first, s.last_name as s_last 
        FROM appointments a 
        JOIN residents r ON a.resident_id = r.id 
        JOIN staff s ON a.staff_id = s.id 
        WHERE a.appointment_date >= CURDATE() 
        ORDER BY a.appointment_date, a.appointment_time 
        LIMIT 5";
if ($role == 'Doctor') {
    $sql = "SELECT a.*, r.first_name as r_first, r.last_name as r_last, s.first_name as s_first, s.last_name as s_last 
            FROM appointments a 
            JOIN residents r ON a.resident_id = r.id 
            JOIN staff s ON a.staff_id = s.id 
            WHERE a.staff_id = $staff_id AND a.appointment_date >= CURDATE() 
            ORDER BY a.appointment_date, a.appointment_time 
            LIMIT 5";
}
$result = $conn->query($sql);
if ($result->num_rows > 0):
?>
<table>
    <thead>
        <tr>
            <th>Date</th>
            <th>Time</th>
            <th>Resident</th>
            <th>Doctor</th>
            <th>Reason</th>
        </tr>
    </thead>
    <tbody>
    <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['appointment_date']; ?></td>
            <td><?php echo $row['appointment_time']; ?></td>
            <td><?php echo htmlspecialchars($row['r_first'] . ' ' . $row['r_last']); ?></td>
            <td><?php echo htmlspecialchars($row['s_first'] . ' ' . $row['s_last']); ?></td>
            <td><?php echo htmlspecialchars($row['reason']); ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
<p>No upcoming appointments.</p>
<?php endif; ?>

<?php include 'footer.php'; ?>