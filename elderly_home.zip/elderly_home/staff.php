<?php
require_once 'config.php';
requireRole(['Admin']); // Only admin can manage staff

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($action == 'add' || $action == 'edit') {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $role = $_POST['role'];
        $specialization = trim($_POST['specialization']);
        $phone = trim($_POST['phone']);
        $email = trim($_POST['email']);

        if ($action == 'add') {
            $stmt = $conn->prepare("INSERT INTO staff (first_name, last_name, role, specialization, phone, email) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $first_name, $last_name, $role, $specialization, $phone, $email);
            $stmt->execute();
            $new_staff_id = $stmt->insert_id;
            $stmt->close();

            // Also create a user account with default password (you may want to send email)
            $username = strtolower($first_name) . '.' . strtolower($last_name);
            $default_password = 'changeme'; // should be hashed
            $password_hash = password_hash($default_password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO users (username, password_hash, role, staff_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sssi", $username, $password_hash, $role, $new_staff_id);
            $stmt->execute();
            $stmt->close();

            header('Location: staff.php?msg=added');
            exit;
        } elseif ($action == 'edit') {
            $stmt = $conn->prepare("UPDATE staff SET first_name=?, last_name=?, role=?, specialization=?, phone=?, email=? WHERE id=?");
            $stmt->bind_param("ssssssi", $first_name, $last_name, $role, $specialization, $phone, $email, $id);
            $stmt->execute();
            $stmt->close();
            header('Location: staff.php?msg=updated');
            exit;
        }
    } elseif ($action == 'delete') {
        // First delete user account (if exists)
        $stmt = $conn->prepare("DELETE FROM users WHERE staff_id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM staff WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        header('Location: staff.php?msg=deleted');
        exit;
    }
}

$result = $conn->query("SELECT * FROM staff ORDER BY role, last_name");
?>
<?php include 'header.php'; ?>
<h1>Staff Management</h1>

<?php if (isset($_GET['msg'])): ?>
    <div class="alert success"><?php echo htmlspecialchars($_GET['msg']); ?></div>
<?php endif; ?>

<?php if ($action == 'add' || ($action == 'edit' && $id)): 
    $staff = null;
    if ($action == 'edit' && $id) {
        $stmt = $conn->prepare("SELECT * FROM staff WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $staff = $result->fetch_assoc();
        $stmt->close();
    }
?>
    <h2><?php echo $action == 'add' ? 'Add New Staff' : 'Edit Staff'; ?></h2>
    <form method="post">
        <div class="form-group">
            <label>First Name*</label>
            <input type="text" name="first_name" value="<?php echo htmlspecialchars($staff['first_name'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
            <label>Last Name*</label>
            <input type="text" name="last_name" value="<?php echo htmlspecialchars($staff['last_name'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
            <label>Role*</label>
            <select name="role" required>
                <option value="Doctor" <?php echo (isset($staff) && $staff['role']=='Doctor') ? 'selected' : ''; ?>>Doctor</option>
                <option value="Nurse" <?php echo (isset($staff) && $staff['role']=='Nurse') ? 'selected' : ''; ?>>Nurse</option>
                <option value="Receptionist" <?php echo (isset($staff) && $staff['role']=='Receptionist') ? 'selected' : ''; ?>>Receptionist</option>
                <option value="Admin" <?php echo (isset($staff) && $staff['role']=='Admin') ? 'selected' : ''; ?>>Admin</option>
            </select>
        </div>
        <div class="form-group">
            <label>Specialization</label>
            <input type="text" name="specialization" value="<?php echo htmlspecialchars($staff['specialization'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo htmlspecialchars($staff['phone'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($staff['email'] ?? ''); ?>">
        </div>
        <button type="submit" class="btn"><?php echo $action == 'add' ? 'Add Staff' : 'Update Staff'; ?></button>
        <a href="staff.php" class="btn btn-secondary">Cancel</a>
    </form>
<?php else: ?>
    <div class="action-bar">
        <a href="?action=add" class="btn">Add New Staff</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Specialization</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                <td><?php echo $row['role']; ?></td>
                <td><?php echo htmlspecialchars($row['specialization']); ?></td>
                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td>
                    <a href="?action=edit&id=<?php echo $row['id']; ?>">Edit</a>
                    <a href="?action=delete&id=<?php echo $row['id']; ?>" onclick="return confirm('Delete this staff member? This will also delete their user account.')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php include 'footer.php'; ?>