<?php
require_once 'config.php';
requireRole(['Admin','Receptionist','Doctor']); // Reception/Admin/Doctor can manage

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// Get doctors list for dropdown
$doctors = $conn->query("SELECT id, first_name, last_name FROM staff WHERE role='Doctor'");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $action == 'schedule') {
    $resident_id = $_POST['resident_id'];
    $staff_id = $_POST['staff_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $reason = trim($_POST['reason']);

    $stmt = $conn->prepare("INSERT INTO appointments (resident_id, staff_id, appointment_date, appointment_time, reason) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $resident_id, $staff_id, $appointment_date, $appointment_time, $reason);
    $stmt->execute();
    $stmt->close();
    header('Location: appointments.php?msg=scheduled');
    exit;
}

// Fetch appointments
$sql = "SELECT a.*, r.first_name as r_first, r.last_name as r_last, s.first_name as s_first, s.last_name as s_last 
        FROM appointments a 
        JOIN residents r ON a.resident_id = r.id 
        JOIN staff s ON a.staff_id = s.id 
        ORDER BY a.appointment_date DESC, a.appointment_time DESC";
$result = $conn->query($sql);
?>
<?php include 'header.php'; ?>
<h1>Appointments</h1>

<?php if (isset($_GET['msg'])): ?>
    <div class="alert success"><?php echo htmlspecialchars($_GET['msg']); ?></div>
<?php endif; ?>

<?php if ($action == 'schedule'): ?>
    <h2>Schedule New Appointment</h2>
    <form method="post">
        <div class="form-group">
            <label>Resident*</label>
            <select name="resident_id" required>
                <option value="">--Select Resident--</option>
                <?php
                $residents = $conn->query("SELECT id, first_name, last_name FROM residents WHERE status='Active'");
                while($res = $residents->fetch_assoc()):
                ?>
                <option value="<?php echo $res['id']; ?>"><?php echo htmlspecialchars($res['first_name'] . ' ' . $res['last_name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Doctor*</label>
            <select name="staff_id" required>
                <option value="">--Select Doctor--</option>
                <?php while($doc = $doctors->fetch_assoc()): ?>
                <option value="<?php echo $doc['id']; ?>"><?php echo htmlspecialchars($doc['first_name'] . ' ' . $doc['last_name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Date*</label>
            <input type="date" name="appointment_date" required min="<?php echo date('Y-m-d'); ?>">
        </div>
        <div class="form-group">
            <label>Time*</label>
            <input type="time" name="appointment_time" required>
        </div>
        <div class="form-group">
            <label>Reason</label>
            <textarea name="reason"></textarea>
        </div>
        <button type="submit" class="btn">Schedule</button>
        <a href="appointments.php" class="btn btn-secondary">Cancel</a>
    </form>
<?php else: ?>
    <div class="action-bar">
        <a href="?action=schedule" class="btn">Schedule New Appointment</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Time</th>
                <th>Resident</th>
                <th>Doctor</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['appointment_date']; ?></td>
                <td><?php echo $row['appointment_time']; ?></td>
                <td><?php echo htmlspecialchars($row['r_first'] . ' ' . $row['r_last']); ?></td>
                <td><?php echo htmlspecialchars($row['s_first'] . ' ' . $row['s_last']); ?></td>
                <td><?php echo htmlspecialchars($row['reason']); ?></td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <?php if ($row['status'] == 'Scheduled'): ?>
                        <a href="appointments.php?action=checkin&id=<?php echo $row['id']; ?>">Check In</a>
                        <!-- We'll handle check-in/out via simple updates -->
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php include 'footer.php'; ?>