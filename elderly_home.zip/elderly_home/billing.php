<?php
require_once 'config.php';
requireRole(['Admin','Receptionist']); // Only admin/reception

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $action == 'add') {
    $resident_id = $_POST['resident_id'];
    $description = trim($_POST['description']);
    $amount = $_POST['amount'];
    $due_date = $_POST['due_date'];
    $invoice_date = date('Y-m-d');

    $stmt = $conn->prepare("INSERT INTO billing (resident_id, invoice_date, description, amount, due_date) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issds", $resident_id, $invoice_date, $description, $amount, $due_date);
    $stmt->execute();
    $stmt->close();
    header('Location: billing.php?msg=added');
    exit;
}

if ($action == 'pay' && $id) {
    $stmt = $conn->prepare("UPDATE billing SET status='Paid' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header('Location: billing.php?msg=paid');
    exit;
}

$result = $conn->query("SELECT b.*, r.first_name, r.last_name FROM billing b JOIN residents r ON b.resident_id = r.id ORDER BY b.invoice_date DESC");
?>
<?php include 'header.php'; ?>
<h1>Billing</h1>

<?php if (isset($_GET['msg'])): ?>
    <div class="alert success"><?php echo htmlspecialchars($_GET['msg']); ?></div>
<?php endif; ?>

<?php if ($action == 'add'): ?>
    <h2>Create New Invoice</h2>
    <form method="post">
        <div class="form-group">
            <label>Resident*</label>
            <select name="resident_id" required>
                <option value="">--Select Resident--</option>
                <?php
                $residents = $conn->query("SELECT id, first_name, last_name FROM residents WHERE status='Active'");
                while($res = $residents->fetch_assoc()):
                ?>
                <option value="<?php echo $res['id']; ?>"><?php echo htmlspecialchars($res['first_name'] . ' ' . $res['last_name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Description*</label>
            <input type="text" name="description" required>
        </div>
        <div class="form-group">
            <label>Amount*</label>
            <input type="number" step="0.01" name="amount" required>
        </div>
        <div class="form-group">
            <label>Due Date</label>
            <input type="date" name="due_date">
        </div>
        <button type="submit" class="btn">Create Invoice</button>
        <a href="billing.php" class="btn btn-secondary">Cancel</a>
    </form>
<?php else: ?>
    <div class="action-bar">
        <a href="?action=add" class="btn">Create New Invoice</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Invoice Date</th>
                <th>Resident</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['invoice_date']; ?></td>
                <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                <td><?php echo htmlspecialchars($row['description']); ?></td>
                <td>$<?php echo number_format($row['amount'], 2); ?></td>
                <td><?php echo $row['status']; ?></td>
                <td><?php echo $row['due_date']; ?></td>
                <td>
                    <?php if ($row['status'] == 'Pending'): ?>
                        <a href="?action=pay&id=<?php echo $row['id']; ?>" onclick="return confirm('Mark as paid?')">Mark Paid</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php include 'footer.php'; ?>