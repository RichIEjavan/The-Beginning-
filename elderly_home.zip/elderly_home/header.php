<?php
// Include config at the top of every page except login
if (basename($_SERVER['PHP_SELF']) != 'index.php') {
    require_once 'config.php';
    requireLogin();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elderly Home Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <?php if (basename($_SERVER['PHP_SELF']) != 'index.php'): ?>
        <nav class="navbar">
            <div class="nav-brand">EHMS</div>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <?php if (in_array($_SESSION['user_role'], ['Admin','Receptionist','Doctor','Nurse'])): ?>
                    <li><a href="residents.php">Residents</a></li>
                <?php endif; ?>
                <?php if ($_SESSION['user_role'] == 'Admin'): ?>
                    <li><a href="staff.php">Staff</a></li>
                <?php endif; ?>
                <?php if (in_array($_SESSION['user_role'], ['Admin','Receptionist','Doctor'])): ?>
                    <li><a href="appointments.php">Appointments</a></li>
                <?php endif; ?>
                <?php if (in_array($_SESSION['user_role'], ['Admin','Receptionist'])): ?>
                    <li><a href="billing.php">Billing</a></li>
                <?php endif; ?>
                <li><a href="search.php">Search</a></li>
                <li><a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['user_name'] ?? $_SESSION['username']); ?>)</a></li>
            </ul>
        </nav>
        <?php endif; ?>
        <main></main>