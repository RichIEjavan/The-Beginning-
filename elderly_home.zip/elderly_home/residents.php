<?php
require_once 'config.php';
requireRole(['Admin','Receptionist','Doctor','Nurse']); // All staff can view, but only Admin/Reception can add/edit/delete

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($action == 'add' || $action == 'edit') {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $dob = $_POST['date_of_birth'];
        $gender = $_POST['gender'];
        $emergency_contact_name = trim($_POST['emergency_contact_name']);
        $emergency_contact_phone = trim($_POST['emergency_contact_phone']);
        $admission_date = $_POST['admission_date'];
        $room_number = trim($_POST['room_number']);

        if ($action == 'add') {
            $stmt = $conn->prepare("INSERT INTO residents (first_name, last_name, date_of_birth, gender, emergency_contact_name, emergency_contact_phone, admission_date, room_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssss", $first_name, $last_name, $dob, $gender, $emergency_contact_name, $emergency_contact_phone, $admission_date, $room_number);
            $stmt->execute();
            $stmt->close();
            header('Location: residents.php?msg=added');
            exit;
        } elseif ($action == 'edit') {
            $stmt = $conn->prepare("UPDATE residents SET first_name=?, last_name=?, date_of_birth=?, gender=?, emergency_contact_name=?, emergency_contact_phone=?, admission_date=?, room_number=? WHERE id=?");
            $stmt->bind_param("ssssssssi", $first_name, $last_name, $dob, $gender, $emergency_contact_name, $emergency_contact_phone, $admission_date, $room_number, $id);
            $stmt->execute();
            $stmt->close();
            header('Location: residents.php?msg=updated');
            exit;
        }
    } elseif ($action == 'discharge') {
        // Discharge: set status to Discharged
        $stmt = $conn->prepare("UPDATE residents SET status='Discharged' WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        header('Location: residents.php?msg=discharged');
        exit;
    }
}

// Fetch residents list
$result = $conn->query("SELECT * FROM residents ORDER BY status DESC, last_name ASC");
?>
<?php include 'header.php'; ?>
<h1>Residents Management</h1>

<?php if (isset($_GET['msg'])): ?>
    <div class="alert success"><?php echo htmlspecialchars($_GET['msg']); ?></div>
<?php endif; ?>

<?php if ($action == 'add' || ($action == 'edit' && $id)): 
    // Fetch data if editing
    $resident = null;
    if ($action == 'edit' && $id) {
        $stmt = $conn->prepare("SELECT * FROM residents WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $resident = $result->fetch_assoc();
        $stmt->close();
    }
?>
    <h2><?php echo $action == 'add' ? 'Add New Resident' : 'Edit Resident'; ?></h2>
    <form method="post" action="?action=<?php echo $action; ?><?php echo $action=='edit' ? '&id='.$id : ''; ?>">
        <div class="form-group">
            <label>First Name*</label>
            <input type="text" name="first_name" value="<?php echo htmlspecialchars($resident['first_name'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
            <label>Last Name*</label>
            <input type="text" name="last_name" value="<?php echo htmlspecialchars($resident['last_name'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
            <label>Date of Birth*</label>
            <input type="date" name="date_of_birth" value="<?php echo $resident['date_of_birth'] ?? ''; ?>" required>
        </div>
        <div class="form-group">
            <label>Gender*</label>
            <select name="gender" required>
                <option value="Male" <?php echo (isset($resident) && $resident['gender']=='Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo (isset($resident) && $resident['gender']=='Female') ? 'selected' : ''; ?>>Female</option>
                <option value="Other" <?php echo (isset($resident) && $resident['gender']=='Other') ? 'selected' : ''; ?>>Other</option>
            </select>
        </div>
        <div class="form-group">
            <label>Emergency Contact Name</label>
            <input type="text" name="emergency_contact_name" value="<?php echo htmlspecialchars($resident['emergency_contact_name'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Emergency Contact Phone</label>
            <input type="text" name="emergency_contact_phone" value="<?php echo htmlspecialchars($resident['emergency_contact_phone'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Admission Date*</label>
            <input type="date" name="admission_date" value="<?php echo $resident['admission_date'] ?? date('Y-m-d'); ?>" required>
        </div>
        <div class="form-group">
            <label>Room Number</label>
            <input type="text" name="room_number" value="<?php echo htmlspecialchars($resident['room_number'] ?? ''); ?>">
        </div>
        <button type="submit" class="btn"><?php echo $action == 'add' ? 'Add Resident' : 'Update Resident'; ?></button>
        <a href="residents.php" class="btn btn-secondary">Cancel</a>
    </form>
<?php else: ?>
    <div class="action-bar">
        <?php if (in_array($_SESSION['user_role'], ['Admin','Receptionist'])): ?>
            <a href="?action=add" class="btn">Add New Resident</a>
        <?php endif; ?>
    </div>

    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Room</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                <td><?php echo $row['date_of_birth']; ?></td>
                <td><?php echo $row['gender']; ?></td>
                <td><?php echo htmlspecialchars($row['room_number']); ?></td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <a href="?action=edit&id=<?php echo $row['id']; ?>">Edit</a>
                    <?php if ($row['status'] == 'Active'): ?>
                        <a href="?action=discharge&id=<?php echo $row['id']; ?>" onclick="return confirm('Discharge this resident?')">Discharge</a>
                    <?php endif; ?>
                    <a href="medical_records.php?resident_id=<?php echo $row['id']; ?>">Medical Records</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php include 'footer.php'; ?>