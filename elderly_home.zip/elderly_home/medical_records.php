<?php
require_once 'config.php';
requireRole(['Admin','Doctor','Nurse']); // Only clinical staff

$resident_id = $_GET['resident_id'] ?? 0;
if (!$resident_id) {
    die("Resident ID required.");
}

// Fetch resident name
$stmt = $conn->prepare("SELECT first_name, last_name FROM residents WHERE id = ?");
$stmt->bind_param("i", $resident_id);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$resident) {
    die("Resident not found.");
}

$action = $_GET['action'] ?? 'list';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $action == 'add') {
    $record_date = $_POST['record_date'];
    $diagnosis = trim($_POST['diagnosis']);
    $observations = trim($_POST['observations']);
    $prescriptions = trim($_POST['prescriptions']);
    $staff_id = $_SESSION['staff_id']; // assuming staff_id is set in session

    $stmt = $conn->prepare("INSERT INTO medical_records (resident_id, staff_id, record_date, diagnosis, observations, prescriptions) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iissss", $resident_id, $staff_id, $record_date, $diagnosis, $observations, $prescriptions);
    $stmt->execute();
    $stmt->close();
    header("Location: medical_records.php?resident_id=$resident_id&msg=added");
    exit;
}

// Fetch records
$stmt = $conn->prepare("SELECT m.*, s.first_name as s_first, s.last_name as s_last FROM medical_records m JOIN staff s ON m.staff_id = s.id WHERE m.resident_id = ? ORDER BY m.record_date DESC");
$stmt->bind_param("i", $resident_id);
$stmt->execute();
$records = $stmt->get_result();
$stmt->close();
?>
<?php include 'header.php'; ?>
<h1>Medical Records for <?php echo htmlspecialchars($resident['first_name'] . ' ' . $resident['last_name']); ?></h1>

<?php if (isset($_GET['msg'])): ?>
    <div class="alert success">Record added.</div>
<?php endif; ?>

<?php if ($action == 'add'): ?>
    <h2>Add New Record</h2>
    <form method="post">
        <div class="form-group">
            <label>Record Date*</label>
            <input type="date" name="record_date" value="<?php echo date('Y-m-d'); ?>" required>
        </div>
        <div class="form-group">
            <label>Diagnosis</label>
            <textarea name="diagnosis"></textarea>
        </div>
        <div class="form-group">
            <label>Observations</label>
            <textarea name="observations"></textarea>
        </div>
        <div class="form-group">
            <label>Prescriptions</label>
            <textarea name="prescriptions"></textarea>
        </div>
        <button type="submit" class="btn">Save Record</button>
        <a href="medical_records.php?resident_id=<?php echo $resident_id; ?>" class="btn btn-secondary">Cancel</a>
    </form>
<?php else: ?>
    <div class="action-bar">
        <a href="?resident_id=<?php echo $resident_id; ?>&action=add" class="btn">Add New Record</a>
        <a href="residents.php" class="btn btn-secondary">Back to Residents</a>
    </div>

    <?php if ($records->num_rows > 0): ?>
        <?php while($rec = $records->fetch_assoc()): ?>
        <div class="record-card">
            <h3><?php echo $rec['record_date']; ?> by Dr. <?php echo htmlspecialchars($rec['s_first'] . ' ' . $rec['s_last']); ?></h3>
            <p><strong>Diagnosis:</strong> <?php echo nl2br(htmlspecialchars($rec['diagnosis'])); ?></p>
            <p><strong>Observations:</strong> <?php echo nl2br(htmlspecialchars($rec['observations'])); ?></p>
            <p><strong>Prescriptions:</strong> <?php echo nl2br(htmlspecialchars($rec['prescriptions'])); ?></p>
        </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No medical records found.</p>
    <?php endif; ?>
<?php endif; ?>

<?php include 'footer.php'; ?>