        </main>
        <footer>
            <p>&copy; <?php echo date('Y'); ?> Elderly Home Management System</p>
        </footer>
    </div>
    <script src="js/script.js"></script>
</body>
</html>