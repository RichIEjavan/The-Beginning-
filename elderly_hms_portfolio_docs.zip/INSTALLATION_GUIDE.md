# ⚙ Installation Guide

## Requirements

-   PHP 8+
-   MySQL 5.7+
-   Apache / XAMPP / WAMP

## Setup Steps

1.  Clone repository:

``` bash
git clone https://github.com/yourusername/elderly-hms.git
```

2.  Import database:

-   Open phpMyAdmin
-   Create database: elderly_hms
-   Import elderly_hms_full_backup.sql

3.  Configure database connection: Update config.php with your
    credentials.

4.  Run project: Place folder in htdocs and visit:
    http://localhost/elderly-hms

------------------------------------------------------------------------

## Default Demo Credentials

(Replace with your own demo credentials before publishing)
