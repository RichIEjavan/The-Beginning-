# 🌟 Feature Documentation

## 1. Resident Management

-   Add, Edit, View Residents
-   Admission Date Tracking
-   Status Updates

## 2. Role-Based Access Control

-   Admin: Full Access
-   Nurse: Limited Medical Updates
-   Receptionist: Registration Only

## 3. Activity Logging

Tracks: - Record Creation - Updates - Deletions

## 4. Dashboard Analytics

Displays: - Total Residents - Active Residents - Discharged This Month -
Average Stay Duration

## 5. Security Features

-   Session validation
-   Prepared statements
-   CSRF-ready structure
