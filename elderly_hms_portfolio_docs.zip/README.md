# 🏥 Elderly Care Hospital Management System (Elderly HMS)

## 📌 Project Overview

Elderly HMS is a web-based Hospital Management System designed to manage
elderly residents in a care facility.\
It supports resident management, role-based access control, activity
logging, and secure authentication.

This project demonstrates: - Secure PHP & MySQL backend development -
Database normalization - Role-based access control (RBAC) - Audit
logging - Soft delete implementation - Dashboard analytics

------------------------------------------------------------------------

## 🚀 Features

-   👤 Resident Registration & Profile Management
-   📅 Admission & Discharge Tracking
-   🔐 Role-Based Access Control (Admin, Nurse, Receptionist)
-   🗂 Activity Logging (Audit Trail)
-   🔎 Advanced Search & Filtering
-   📊 Dashboard with Key Statistics
-   🛡 Secure Authentication (Password Hashing + Sessions)
-   🗑 Soft Delete Implementation

------------------------------------------------------------------------

## 🛠 Tech Stack

-   PHP (Core PHP)
-   MySQL
-   HTML5 / CSS3
-   Bootstrap
-   JavaScript

------------------------------------------------------------------------

## 🗄 Database

The database includes normalized tables such as: - users - residents -
activity_logs - resident_status_history

To restore the database:

``` bash
mysql -u username -p elderly_hms < elderly_hms_full_backup.sql
```

------------------------------------------------------------------------

## 📷 Screenshots

(Add screenshots here after pushing to GitHub)

------------------------------------------------------------------------

## 📚 Learning Outcomes

-   Secure CRUD operations
-   Backend validation & prepared statements
-   Session security
-   Data integrity management
-   Enterprise-level design thinking

------------------------------------------------------------------------

## 📄 License

This project is for portfolio and educational purposes.

------------------------------------------------------------------------

**Author:** Your Name\
**Date:** 2026-02-22
