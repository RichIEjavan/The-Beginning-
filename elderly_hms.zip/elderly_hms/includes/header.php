<?php
if(!isset($_SESSION)) session_start();
require_once "../config/database.php";
require_once "../includes/permission.php";

if(!isset($_SESSION['user'])){
    header("Location: ../auth/login.php");
    exit();
}

$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Elderly HMS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
body { background-color:#f4f6f9; }
.sidebar {
    height:100vh;
    background:#343a40;
    color:white;
}
.sidebar a {
    color:white;
    display:block;
    padding:10px;
    text-decoration:none;
}
.sidebar a:hover {
    background:#495057;
}
.sidebar h4 {
    color:#fff;
}
.badge-role {
    font-size:12px;
}
</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-3">

<h4><i class="bi bi-hospital"></i> Elderly HMS</h4>
<hr>

<a href="../dashboard/dashboard.php">
<i class="bi bi-speedometer2"></i> Dashboard
</a>

<?php if(hasPermission('view_residents')): ?>
<a href="../residents/list.php">
<i class="bi bi-people"></i> Residents
</a>
<?php endif; ?>

<?php if(hasPermission('manage_appointments')): ?>
<a href="../appointments/list.php">
<i class="bi bi-calendar"></i> Appointments
</a>
<?php endif; ?>

<?php if(hasPermission('add_medical_record')): ?>
<a href="../medical/view_records.php">
<i class="bi bi-file-medical"></i> Medical Records
</a>
<?php endif; ?>

<?php if(hasPermission('view_billing')): ?>
<a href="../billing/list.php">
<i class="bi bi-cash"></i> Billing
</a>
<?php endif; ?>

<?php if(hasPermission('manage_users')): ?>
<a href="../auth/register.php">
<i class="bi bi-person-plus"></i> Manage Staff
</a>
<?php endif; ?>

<hr>

<a href="../auth/logout.php">
<i class="bi bi-box-arrow-right"></i> Logout
</a>

</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<div class="d-flex justify-content-between mb-4">
<h3>Welcome <?php echo htmlspecialchars($user['username']); ?></h3>
<span class="badge bg-primary badge-role">
<?php 
// Fetch role name dynamically
$stmt = $conn->prepare("SELECT role_name FROM roles WHERE id=?");
$stmt->bind_param("i", $user['role_id']);
$stmt->execute();
$result = $stmt->get_result();
$roleData = $result->fetch_assoc();
echo strtoupper($roleData['role_name']);
?>
</span>
</div>