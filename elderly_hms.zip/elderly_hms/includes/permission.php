<?php
function hasPermission($permission){
    global $conn;

    if(!isset($_SESSION['user'])) return false;

    $role_id = $_SESSION['user']['role_id'];

    $stmt = $conn->prepare("
        SELECT p.permission_name
        FROM permissions p
        JOIN role_permissions rp ON p.id = rp.permission_id
        WHERE rp.role_id=? AND p.permission_name=?
    ");
    $stmt->bind_param("is",$role_id,$permission);
    $stmt->execute();
    $result = $stmt->get_result();

    return $result->num_rows > 0;
}
?>