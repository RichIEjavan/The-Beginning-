<?php

/*
|--------------------------------------------------------------------------
| Start Session (Only Once)
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Database Connection
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/database.php';

/*
|--------------------------------------------------------------------------
| Permission System
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/../includes/permission.php';

/*
|--------------------------------------------------------------------------
| Flash Message Helper
|--------------------------------------------------------------------------
*/
if (!function_exists('flash')) {
    function flash($type, $message) {
        $_SESSION['flash'] = [
            'type' => $type,
            'message' => $message
        ];
    }
}

/*
|--------------------------------------------------------------------------
| Display Flash
|--------------------------------------------------------------------------
*/
if (!function_exists('displayFlash')) {
    function displayFlash() {
        if (isset($_SESSION['flash'])) {
            $flash = $_SESSION['flash'];

            echo "<div class='alert alert-{$flash['type']}'>";
            echo $flash['message'];
            echo "</div>";

            unset($_SESSION['flash']);
        }
    }
}