<?php
$conn = new mysqli("localhost","root","","elderly_hms");

if ($conn->connect_error) {
    die("DB Connection Failed: " . $conn->connect_error);
}