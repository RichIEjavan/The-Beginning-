<?php
/*
|--------------------------------------------------------------------------
| HASH GENERATOR FOR HMS
|--------------------------------------------------------------------------
| Use this file to generate secure password hashes.
| Example: http://localhost/HMS2/hash.php?password=admin123
|--------------------------------------------------------------------------
*/

if (!isset($_GET['password'])) {
    echo "<h3>HMS Password Hash Generator</h3>";
    echo "<form method='GET'>
            <input type='text' name='password' placeholder='Enter password' required>
            <button type='submit'>Generate Hash</button>
          </form>";
    exit();
}

$password = $_GET['password'];

// Generate secure hash
$hash = password_hash($password, PASSWORD_DEFAULT);

echo "<h3>Password Hash Generated Successfully</h3>";
echo "<strong>Plain Password:</strong> " . htmlspecialchars($password) . "<br><br>";
echo "<strong>Hashed Password:</strong><br>";
echo "<textarea rows='4' cols='80'>$hash</textarea><br><br>";

echo "<small>Copy this hash and insert into your users table.</small>";
?>