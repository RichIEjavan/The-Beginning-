<?php
require_once __DIR__ . '/../config/init.php';

// Permission check
if(!hasPermission('edit_residents')){
    die("Access Denied");
}

// Get resident ID safely
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if($id <= 0){
    flash('danger', 'Invalid resident ID');
    header("Location: list.php");
    exit();
}

// Fetch resident
$stmt = $conn->prepare("SELECT * FROM residents WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();

if(!$resident){
    flash('danger', 'Resident not found');
    header("Location: list.php");
    exit();
}

// Handle submission
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $status = $_POST['status'];
    $allergies = trim($_POST['allergies']);
    $chronic_conditions = trim($_POST['chronic_conditions']);
    $assigned_doctor = $_POST['assigned_doctor'] ?: NULL;
    $admission_date = $_POST['admission_date'];
    $emergency_name = trim($_POST['emergency_contact_name']);
    $emergency_phone = trim($_POST['emergency_contact_phone']);
    $photo = $resident['photo'];

    if(isset($_FILES['photo']) && $_FILES['photo']['error'] === 0){
        $targetDir = __DIR__ . '/../uploads/';
        $filename = time() . '_' . basename($_FILES['photo']['name']);
        $targetFile = $targetDir . $filename;
        if(move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)){
            $photo = $filename;
        }
    }

    $stmt = $conn->prepare("
        UPDATE residents SET 
        firstname=?, lastname=?, dob=?, gender=?, phone=?, address=?, status=?, allergies=?, chronic_conditions=?, assigned_doctor=?, admission_date=?, emergency_contact_name=?, emergency_contact_phone=?, photo=?
        WHERE id=?
    ");
    $stmt->bind_param(
        "ssssssssssisssi",
        $firstname, $lastname, $dob, $gender, $phone, $address, $status, $allergies, $chronic_conditions, $assigned_doctor, $admission_date, $emergency_name, $emergency_phone, $photo, $id
    );

    if($stmt->execute()){
        flash('success', 'Resident updated successfully!');
        header("Location: profile.php?id=$id");
        exit();
    } else {
        flash('danger', 'Error updating resident: '.$stmt->error);
    }
}

// Fetch doctors for dropdown
$doctors = $conn->query("SELECT id, username FROM users WHERE role='doctor'");

include __DIR__ . '/../includes/header.php';
displayFlash();
?>

<h4>Edit Resident</h4>

<form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label>First Name</label>
        <input type="text" name="firstname" class="form-control" value="<?php echo htmlspecialchars($resident['firstname']); ?>" required>
    </div>
    <div class="mb-3">
        <label>Last Name</label>
        <input type="text" name="lastname" class="form-control" value="<?php echo htmlspecialchars($resident['lastname']); ?>" required>
    </div>
    <div class="mb-3">
        <label>Date of Birth</label>
        <input type="date" name="dob" class="form-control" value="<?php echo $resident['dob']; ?>" required>
    </div>
    <div class="mb-3">
        <label>Gender</label>
        <select name="gender" class="form-control">
            <option value="">Select Gender</option>
            <option value="Male" <?php if($resident['gender']=='Male') echo 'selected'; ?>>Male</option>
            <option value="Female" <?php if($resident['gender']=='Female') echo 'selected'; ?>>Female</option>
        </select>
    </div>
    <div class="mb-3">
        <label>Phone</label>
        <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($resident['phone']); ?>">
    </div>
    <div class="mb-3">
        <label>Address</label>
        <textarea name="address" class="form-control"><?php echo htmlspecialchars($resident['address']); ?></textarea>
    </div>
    <div class="mb-3">
        <label>Status</label>
        <select name="status" class="form-control">
            <option value="active" <?php if($resident['status']=='active') echo 'selected'; ?>>Active</option>
            <option value="discharged" <?php if($resident['status']=='discharged') echo 'selected'; ?>>Discharged</option>
        </select>
    </div>
    <div class="mb-3">
        <label>Allergies</label>
        <input type="text" name="allergies" class="form-control" value="<?php echo htmlspecialchars($resident['allergies']); ?>">
    </div>
    <div class="mb-3">
        <label>Chronic Conditions</label>
        <input type="text" name="chronic_conditions" class="form-control" value="<?php echo htmlspecialchars($resident['chronic_conditions']); ?>">
    </div>
    <div class="mb-3">
        <label>Assigned Doctor</label>
        <select name="assigned_doctor" class="form-control">
            <option value="">Select Doctor</option>
            <?php while($doc = $doctors->fetch_assoc()): ?>
                <option value="<?php echo $doc['id']; ?>" <?php if($doc['id']==$resident['assigned_doctor']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($doc['username']); ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="mb-3">
        <label>Admission Date</label>
        <input type="date" name="admission_date" class="form-control" value="<?php echo $resident['admission_date']; ?>" required>
    </div>
    <div class="mb-3">
        <label>Emergency Contact Name</label>
        <input type="text" name="emergency_contact_name" class="form-control" value="<?php echo htmlspecialchars($resident['emergency_contact_name']); ?>">
    </div>
    <div class="mb-3">
        <label>Emergency Contact Phone</label>
        <input type="text" name="emergency_contact_phone" class="form-control" value="<?php echo htmlspecialchars($resident['emergency_contact_phone']); ?>">
    </div>
    <div class="mb-3">
        <label>Photo</label>
        <input type="file" name="photo" class="form-control">
    </div>
    <button class="btn btn-primary">Save Changes</button>
    <a href="profile.php?id=<?php echo $resident['id']; ?>" class="btn btn-secondary">Cancel</a>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>