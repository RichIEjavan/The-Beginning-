<?php
require_once __DIR__ . '/../config/init.php';

// Permission check
if(!hasPermission('add_residents')){
    die("Access Denied");
}

// Handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $status = $_POST['status'];
    $allergies = trim($_POST['allergies']);
    $chronic_conditions = trim($_POST['chronic_conditions']);
    $assigned_doctor = $_POST['assigned_doctor'] ?: NULL;
    $admission_date = $_POST['admission_date'];
    $emergency_name = trim($_POST['emergency_contact_name']);
    $emergency_phone = trim($_POST['emergency_contact_phone']);
    $photo = '';

    // Handle photo upload
    if(isset($_FILES['photo']) && $_FILES['photo']['error'] === 0){
        $targetDir = __DIR__ . '/../uploads/';
        $filename = time() . '_' . basename($_FILES['photo']['name']);
        $targetFile = $targetDir . $filename;
        if(move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)){
            $photo = $filename;
        }
    }

    // Insert into DB
    $stmt = $conn->prepare("
        INSERT INTO residents
        (firstname, lastname, dob, gender, phone, address, status, allergies, chronic_conditions, assigned_doctor, admission_date, emergency_contact_name, emergency_contact_phone, photo)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ");
    $stmt->bind_param(
        "ssssssssssisss",
        $firstname, $lastname, $dob, $gender, $phone, $address, $status, $allergies, $chronic_conditions, $assigned_doctor, $admission_date, $emergency_name, $emergency_phone, $photo
    );

    if($stmt->execute()){
        flash('success', 'Resident added successfully!');
        header("Location: list.php");
        exit();
    } else {
        flash('danger', 'Error adding resident: ' . $stmt->error);
    }
}

// Fetch doctors for select dropdown
$doctors = $conn->query("SELECT id, username FROM users WHERE role='doctor'");

include __DIR__ . '/../includes/header.php';
?>

<h4>Add Resident</h4>

<?php displayFlash(); ?>

<form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label>First Name</label>
        <input type="text" name="firstname" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Last Name</label>
        <input type="text" name="lastname" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Date of Birth</label>
        <input type="date" name="dob" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Gender</label>
        <select name="gender" class="form-control">
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
    </div>
    <div class="mb-3">
        <label>Phone</label>
        <input type="text" name="phone" class="form-control">
    </div>
    <div class="mb-3">
        <label>Address</label>
        <textarea name="address" class="form-control"></textarea>
    </div>
    <div class="mb-3">
        <label>Status</label>
        <select name="status" class="form-control">
            <option value="active">Active</option>
            <option value="discharged">Discharged</option>
        </select>
    </div>
    <div class="mb-3">
        <label>Allergies</label>
        <input type="text" name="allergies" class="form-control">
    </div>
    <div class="mb-3">
        <label>Chronic Conditions</label>
        <input type="text" name="chronic_conditions" class="form-control">
    </div>
    <div class="mb-3">
        <label>Assigned Doctor</label>
        <select name="assigned_doctor" class="form-control">
            <option value="">Select Doctor</option>
            <?php while($doc = $doctors->fetch_assoc()): ?>
                <option value="<?php echo $doc['id']; ?>"><?php echo htmlspecialchars($doc['username']); ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="mb-3">
        <label>Admission Date</label>
        <input type="date" name="admission_date" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Emergency Contact Name</label>
        <input type="text" name="emergency_contact_name" class="form-control">
    </div>
    <div class="mb-3">
        <label>Emergency Contact Phone</label>
        <input type="text" name="emergency_contact_phone" class="form-control">
    </div>
    <div class="mb-3">
        <label>Photo</label>
        <input type="file" name="photo" class="form-control">
    </div>
    <button class="btn btn-primary">Add Resident</button>
    <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>