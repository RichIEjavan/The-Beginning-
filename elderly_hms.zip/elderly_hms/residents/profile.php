<?php
require_once __DIR__ . '/../config/init.php';

// Permission check
if(!hasPermission('view_residents')){
    die("Access Denied");
}

// Get resident ID safely
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if($id <= 0){
    flash('danger','Invalid resident ID');
    header("Location: list.php");
    exit();
}

// Fetch resident
$stmt = $conn->prepare("
    SELECT r.*, u.username AS doctor_name 
    FROM residents r
    LEFT JOIN users u ON r.assigned_doctor = u.id
    WHERE r.id = ?
");
$stmt->bind_param("i",$id);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();

if(!$resident){
    flash('danger','Resident not found');
    header("Location: list.php");
    exit();
}

include __DIR__ . '/../includes/header.php';
displayFlash();
?>

<h4>Resident Profile: <?php echo htmlspecialchars($resident['firstname'] . ' ' . $resident['lastname']); ?></h4>

<p><strong>Status:</strong> <?php echo strtoupper($resident['status']); ?></p>
<p><strong>Doctor:</strong> <?php echo $resident['doctor_name'] ?? 'Not Assigned'; ?></p>
<p><strong>Date of Birth:</strong> <?php echo $resident['dob']; ?></p>
<p><strong>Admission Date:</strong> <?php echo $resident['admission_date']; ?></p>
<p><strong>Phone:</strong> <?php echo $resident['phone']; ?></p>
<p><strong>Address:</strong> <?php echo htmlspecialchars($resident['address']); ?></p>
<p><strong>Allergies:</strong> <?php echo htmlspecialchars($resident['allergies']); ?></p>
<p><strong>Chronic Conditions:</strong> <?php echo htmlspecialchars($resident['chronic_conditions']); ?></p>
<p><strong>Emergency Contact:</strong> <?php echo htmlspecialchars($resident['emergency_contact_name']); ?> (<?php echo htmlspecialchars($resident['emergency_contact_phone']); ?>)</p>

<?php if($resident['photo']): ?>
    <p><img src="../uploads/<?php echo $resident['photo']; ?>" alt="Photo" width="150"></p>
<?php endif; ?>

<a href="edit.php?id=<?php echo $resident['id']; ?>" class="btn btn-warning">Edit Resident</a>

<?php include __DIR__ . '/../includes/footer.php'; ?>