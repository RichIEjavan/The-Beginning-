<?php
require_once __DIR__ . '/../config/init.php';

// Permission check
if(!hasPermission('view_residents')){
    die("Access Denied");
}

include __DIR__ . '/../includes/header.php';

// Display flash messages
displayFlash();

// Fetch all residents
$result = $conn->query("
    SELECT r.*, u.username AS doctor_name
    FROM residents r
    LEFT JOIN users u ON r.assigned_doctor = u.id
    ORDER BY r.id DESC
");
?>

<h4>Residents</h4>
<a href="add.php" class="btn btn-primary mb-3">Add Resident</a>

<table class="table table-bordered">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Status</th>
    <th>Doctor</th>
    <th>Admission</th>
    <th>Actions</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></td>
    <td><?php echo strtoupper($row['status']); ?></td>
    <td><?php echo $row['doctor_name'] ?? 'Not Assigned'; ?></td>
    <td><?php echo $row['admission_date']; ?></td>
    <td>
        <a href="profile.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">View</a>
        <?php if(hasPermission('edit_residents')): ?>
            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
        <?php endif; ?>
    </td>
</tr>
<?php endwhile; ?>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>