<?php
require_once "../config/database.php";

if(isset($_GET['token'])){
    $token=$_GET['token'];
    $stmt=$conn->prepare("SELECT * FROM users WHERE reset_token=? AND reset_expiry > NOW()");
    $stmt->bind_param("s",$token);
    $stmt->execute();
    $result=$stmt->get_result();

    if($result->num_rows==1){
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $newpass=password_hash($_POST['password'],PASSWORD_DEFAULT);
            $conn->query("UPDATE users SET password='$newpass', reset_token=NULL, reset_expiry=NULL WHERE reset_token='$token'");
            echo "Password Updated Successfully!";
            exit();
        }
?>

<form method="POST">
<h3>Reset Password</h3>
<input type="password" name="password" required placeholder="New Password">
<button>Reset</button>
</form>

<?php
    } else {
        echo "Invalid or Expired Token!";
    }
}
?>