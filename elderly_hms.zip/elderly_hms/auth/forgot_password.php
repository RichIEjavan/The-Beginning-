<?php
require_once "../config/database.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $username=$_POST['username'];
    $token=bin2hex(random_bytes(32));
    $expiry=date("Y-m-d H:i:s",strtotime("+1 hour"));

    $stmt=$conn->prepare("UPDATE users SET reset_token=?, reset_expiry=? WHERE username=?");
    $stmt->bind_param("sss",$token,$expiry,$username);
    $stmt->execute();

    $message="Password reset link created. 
    Go to: http://localhost/elderly_hms/auth/reset_password.php?token=$token";
}
?>

<form method="POST">
<h3>Forgot Password</h3>
<input name="username" required placeholder="Enter Username">
<button>Generate Reset Link</button>
</form>

<?php if(isset($message)) echo "<p>$message</p>"; ?>