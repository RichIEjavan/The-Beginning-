<?php
require_once __DIR__ . '/../config/init.php';

if(!isset($_SESSION)) session_start();

/* REMEMBER ME AUTO LOGIN */
if(isset($_COOKIE['remember_user']) && !isset($_SESSION['user'])){
    $username = $_COOKIE['remember_user'];
    $stmt=$conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->bind_param("s",$username);
    $stmt->execute();
    $result=$stmt->get_result();
    if($result->num_rows==1){
        $_SESSION['user']=$result->fetch_assoc();
        header("Location: ../dashboard/dashboard.php");
        exit();
    }
}

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $username=trim($_POST['username']);
    $password=trim($_POST['password']);
    $remember=isset($_POST['remember']);

    $stmt=$conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->bind_param("s",$username);
    $stmt->execute();
    $result=$stmt->get_result();

    if($result->num_rows==1){
        $user=$result->fetch_assoc();
        if(password_verify($password,$user['password'])){
            $_SESSION['user']=$user;

            if($remember){
                setcookie("remember_user",$username,time()+86400*30,"/");
            }

            header("Location: ../dashboard/dashboard.php");
            exit();
        }
    }
    $error="Invalid Username or Password!";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Elderly HMS Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
body{
    background: linear-gradient(135deg,#0d6efd,#6610f2);
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}
.login-card{
    width:420px;
    border-radius:15px;
    animation:fadeIn 0.8s ease-in-out;
}
@keyframes fadeIn{
    from{opacity:0; transform:translateY(-20px);}
    to{opacity:1; transform:translateY(0);}
}
.logo-img{
    width:80px;
    height:80px;
    object-fit:contain;
}
</style>
</head>

<body>

<div class="card shadow-lg login-card">
<div class="card-body p-4 text-center">

<?php
$logoPath = "../assets/images/logo.png";
if(file_exists($logoPath)){
    echo "<img src='$logoPath' class='logo-img mb-2'>";
}
?>

<h4 class="text-primary">Elderly HMS</h4>
<p class="text-muted">Secure Staff Login</p>

<?php if(isset($error)): ?>
<div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<form method="POST">
<div class="mb-3 text-start">
<label>Username</label>
<input type="text" name="username" class="form-control" required>
</div>

<div class="mb-3 text-start">
<label>Password</label>
<div class="input-group">
<input type="password" id="password" name="password" class="form-control" required>
<button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
<i class="bi bi-eye"></i>
</button>
</div>
</div>

<div class="form-check text-start mb-3">
<input type="checkbox" name="remember" class="form-check-input">
<label class="form-check-label">Remember Me</label>
</div>

<button class="btn btn-primary w-100">Login</button>
</form>

<div class="mt-3">
<a href="forgot_password.php">Forgot Password?</a>
</div>

</div>
</div>

<script>
function togglePassword(){
    var p=document.getElementById("password");
    p.type = p.type==="password" ? "text":"password";
}
</script>

</body>
</html>