<?php require_once "../config/database.php"; ?>
<?php include "../includes/header.php"; ?>

<?php
$residents = $conn->query("SELECT COUNT(*) as total FROM residents")->fetch_assoc()['total'];
$appointments = $conn->query("SELECT COUNT(*) as total FROM appointments")->fetch_assoc()['total'];
$billing = $conn->query("SELECT SUM(amount) as total FROM billing")->fetch_assoc()['total'];
?>

<div class="row">
<div class="col-md-4">
<div class="card card-stat shadow">
<div class="card-body">
<h5>Total Residents</h5>
<h2><?php echo $residents; ?></h2>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card card-stat shadow">
<div class="card-body">
<h5>Total Appointments</h5>
<h2><?php echo $appointments; ?></h2>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card card-stat shadow">
<div class="card-body">
<h5>Total Revenue</h5>
<h2>Ksh <?php echo $billing ? $billing : 0; ?></h2>
</div>
</div>
</div>
</div>

<?php include "../includes/footer.php"; ?>